package com.itheima.demo9;

/**
 * 泛型接口
 * @param <T>
 */
public interface Info<T> {
    T info(T t);
}
