package com.itheima.demo5;

/**
 * 泛型接口
 * @param <T>
 */
public interface Generator<T> {
    T getKey();
}
